Hi, this project was made in a hurry, so it has some bugs and problems.
You only need to change the paths (like path_inventory and path_login_excel).
You cannot have "catalogo - Copy" open while adding, reading, and removing videogames.
You can change the usernames and passwords without problem.

The program doesn't close the excels, so you need to close them with Task Manager
or your computer will start to get slow (and also causes problems with the program).
I recommend closing them everytime you finish using the program.